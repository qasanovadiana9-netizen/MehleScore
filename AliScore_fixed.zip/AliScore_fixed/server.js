const express = require('express');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const app = express();
const PORT = process.env.PORT || 3000;
const DATA_FILE = path.join(__dirname, 'data.json');

if (!process.env.ADMIN_PASSWORD) console.warn('ADMIN_PASSWORD Render Environment Variable olaraq əlavə edilməlidir.');
if (!process.env.SESSION_SECRET) console.warn('SESSION_SECRET Render Environment Variable olaraq əlavə edilməlidir.');

let data = JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
const sessions = new Map();

app.use(express.json({ limit: '1mb' }));

function saveData() {
  fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
}

function makeToken() {
  const raw = crypto.randomBytes(32).toString('hex');
  const secret = process.env.SESSION_SECRET || 'change-this-secret';
  return crypto.createHmac('sha256', secret).update(raw).digest('hex');
}

function getToken(req) {
  const cookie = req.headers.cookie || '';
  const m = cookie.match(/(?:^|;\s*)aliscore_session=([^;]+)/);
  return m ? m[1] : null;
}

function requireAdmin(req, res, next) {
  const token = getToken(req);
  const expires = token ? sessions.get(token) : null;
  if (!expires || expires < Date.now()) {
    if (token) sessions.delete(token);
    return res.status(401).json({ error: 'Admin girişi tələb olunur.' });
  }
  next();
}

app.get('/api/data', (req, res) => {
  const token = getToken(req);
  const expires = token ? sessions.get(token) : null;
  const isAdmin = Boolean(expires && expires >= Date.now());
  res.json({ data, isAdmin });
});

app.post('/api/login', (req, res) => {
  const password = String(req.body?.password || '');
  if (!process.env.ADMIN_PASSWORD || password !== process.env.ADMIN_PASSWORD) {
    return res.status(401).json({ error: 'Şifrə yanlışdır.' });
  }
  const token = makeToken();
  sessions.set(token, Date.now() + 24 * 60 * 60 * 1000);
  const secure = process.env.NODE_ENV === 'production' ? '; Secure' : '';
  res.setHeader('Set-Cookie', `aliscore_session=${token}; HttpOnly; SameSite=Lax; Path=/; Max-Age=86400${secure}`);
  res.json({ ok: true });
});

app.post('/api/logout', (req, res) => {
  const token = getToken(req);
  if (token) sessions.delete(token);
  res.setHeader('Set-Cookie', 'aliscore_session=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0');
  res.json({ ok: true });
});

app.put('/api/data', requireAdmin, (req, res) => {
  const incoming = req.body;
  if (!incoming || !Array.isArray(incoming.matches) || !Array.isArray(incoming.leagues) || !Array.isArray(incoming.teams) || !Array.isArray(incoming.players)) {
    return res.status(400).json({ error: 'Məlumat formatı düzgün deyil.' });
  }
  data = incoming;
  saveData();
  res.json({ data, isAdmin: true });
});

app.use(express.static(path.join(__dirname, 'public')));
app.use((req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));

app.listen(PORT, () => console.log(`AliScore running on port ${PORT}`));
