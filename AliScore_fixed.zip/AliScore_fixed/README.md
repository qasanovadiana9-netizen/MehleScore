# AliScore — secure admin version

Bu versiya mövcud AliScore dizaynını saxlayır, amma admin şifrəsini `index.html` daxilində saxlamır.

## Render
- Build Command: `npm install`
- Start Command: `npm start`
- Environment Variables:
  - `ADMIN_PASSWORD` = öz admin şifrən
  - `SESSION_SECRET` = uzun təsadüfi mətn

Qeyd: brauzerə göndərilən `index.html` yenə istifadəçiyə görünə bilər. Gizli olan hissələr admin şifrəsi və serverdəki admin yoxlamasıdır.
